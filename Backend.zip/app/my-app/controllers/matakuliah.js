const connection = require("../db/db");

module.exports = {
    getMk: (req,res) => {
        const qstring = "SELECT * FROM matakuliah";
        connection.query(qstring, (err,data) => {
            if (err) {
                console.log("error: ", err);
                res.status(500).send({
                    message : err.message || "Terjadi kesalahan saat get data"
                });
            }
            else res.send(data)
        });
    },

    getMkBykdMk: (req,res) => {
        const qstring = `SELECT * FROM matakuliah WHERE kdMk = '${req.params.kdMk}'`;
        connection.query(qstring, (err,data) => {
            if (err) {
                console.log("error: ", err);
                res.status(500).send({
                    message : err.message || "Terjadi kesalahan saat get data"
                });
            }
            else res.send(data)
        });
    },

    create: (req,res) => {
        const mkBaru = req.body;
    
        connection.query("INSERT INTO matakuliah SET ?", mkBaru,(err) => {
            if (err) {
                console.log("error:", err);
                res.status(500).send({
                    message : err.message || "Terjadi kesalahan saat insert data"
                });
            }
            else
                res.send(mkBaru)
        });
    },

    update:  (req, res) => {
        const kdMk = req.params.kdMk;
        const matakuliah = req.body;
        const qstring = `UPDATE matakuliah
                        SET matakuliah = '${matakuliah.matakuliah}', sks = '${matakuliah.sks}', semester = '${matakuliah.semester}'
                        WHERE kdMk = '${kdMk}'`
        connection.query(qstring, (err,data) => {
            if(err) {
                res.status(500).send({
                    message: "Error updating matakuliah with kdMk" + kdMk
                });
            }
            else if(data.affectedRows == 0){
                res.status(404).send({
                    message: `Not found matakuliah with kdMk ${kdMk}.`
                });
            }
            else {
                console.log("update matakuliah:", { kdMk: kdMk, ...matakuliah});
                res.send({ kdMk: kdMk, ...matakuliah});
            }
        })
    },

    delete: (req,res) => {
        const kdMk = req.params.kdMk;
        const qstring = `DELETE FROM matakuliah WHERE kdMk = '${kdMk}'`;
        connection.query(qstring, (err, data) => {
            if(err) {
                res.status(500).send({
                    message: "Error deleting matakuliah with kdMk" + kdMk,
                });
            }
            else if(data.affectedRows == 0){
                res.status(404).send({
                    message: `Not found matakuliah with kdMk ${kdMk}.`,
                });
            }
            else res.send(`Matakuliah dengan kdMk = ${kdMk} telah terhapus`)
        });
    }
}