const express = require('express')
const routerMk = express.Router()
const connection = require('../db/db.js')
const ctrMk = require('../controllers/matakuliah')

routerMk.get('/matakuliah',ctrMk.getMk)
routerMk.get('/matakuliah/:kdMk',ctrMk.getMkBykdMk)
routerMk.post('/matakuliah',ctrMk.create)
routerMk.put('/matakuliah/:kdMk',ctrMk.update)
routerMk.delete('/matakuliah/:kdMk',ctrMk.delete)

module.exports = routerMk